<?php $__env->startSection('content'); ?>   
<?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="<?php echo e(URL::to('/public/upload/product/'.$product->product_image)); ?>" alt="" />
								
							</div>
						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<img src="<?php echo e(url::to('/public/frontend/images/new.jpg')); ?>" class="newarrival" alt="" />
								<h2><?php echo e($product->product_name); ?></h2>
								<form>
									<?php echo e(csrf_field()); ?>

								<span>
									<span><?php echo e(number_format($product->product_price)); ?> VND</span>
									<label>Số lượng:</label>
									<input type="number" min="1" value="1" max="<?php echo e($product->product_quantity); ?>" class="cart_product_qty_<?php echo e($product->product_id); ?>">
									<p>Số lượng tồn : <?php echo e($product->product_quantity); ?></p>
								</span>
									<input type="hidden" value="<?php echo e($product->product_id); ?>" class="cart_product_id_<?php echo e($product->product_id); ?>">
									<input type="hidden" value="<?php echo e($product->product_name); ?>" class="cart_product_name_<?php echo e($product->product_id); ?>">
									<input type="hidden" value="<?php echo e($product->product_image); ?>" class="cart_product_image_<?php echo e($product->product_id); ?>">
									<input type="hidden" value="<?php echo e($product->product_price); ?>" class="cart_product_price_<?php echo e($product->product_id); ?>">
									<input type="hidden" value="<?php echo e($product->product_quantity); ?>" class="cart_product_quantity_<?php echo e($product->product_id); ?>">
									
									<button type="button" class="btn btn-fefault add-to-cart" data-id_product="<?php echo e($product->product_id); ?>">
										Thêm giỏ hàng
									</button>
								</form>
								<p><b>Tình trạng:</b> Còn hàng</p>
								<p><b>Điều kiện:</b> Mới</p>
								<p><b>Danh mục:</b> <?php echo e($product->category_name); ?></p>
								<a href=""><img src="<?php echo e(URL::to('/public/frontend/images/share.png')); ?>" class="share img-responsive"  alt="" /></a>
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->

                    <div class="category-tab shop-details-tab"><!--category-tab-->
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#details" data-toggle="tab">Mô tả sản phẩm</a></li>
								<li><a href="#companyprofile" data-toggle="tab">Thông tin nguyên vật liệu</a></li>
								
							</ul>
						</div>
						<div class="tab-content">
							<div class="tab-pane fade active in" id="details" >
								<p>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $product->product_desc; ?></p>
							</div>
							
							<div class="tab-pane fade" id="companyprofile" >
								<p>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $product->product_content; ?></p>
								
							</div>
							
						</div>
					</div><!--/category-tab-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php
						use Illuminate\Support\Facades\Crypt;
					?>
                    <div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Sản phẩm liên quan</h2>
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	
								<?php $__currentLoopData = $relate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$pro_encrypted = Crypt::encryptString((string)$rela->product_id);
								?>
									<a href="<?php echo e(URL::to('/chi-tiet-san-pham/'.$pro_encrypted)); ?>">
									<div class="col-sm-4">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="../public/upload/product/<?php echo e($rela->product_image); ?>" height="255px" alt="" />
												<h2><?php echo e(number_format($rela->product_price)); ?> VNĐ</h2>
												<p><?php echo e($rela->product_name); ?></p>
												<form action="<?php echo e(URL::to('/save-cart')); ?>" method="POST">
													<?php echo e(csrf_field()); ?>

													<input name="qty" type="hidden" value="1" />
													<input name="productid_hidden" type="hidden" value="<?php echo e($rela->product_id); ?>" />
													<button style="height:35px; width:150px;" type="submit" class="btn btn-fefault cart">
														<i class="fa fa-shopping-cart"></i>
														Add to cart
													</button>&nbsp; &nbsp; &nbsp;
												</form>
											</div>
										</div>
									</div>
									</a>	
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								<div class="item">	
								<?php $__currentLoopData = $relate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$pro_encrypted = Crypt::encryptString((string)$rela->product_id);
								?>
									<a href="<?php echo e(URL::to('/chi-tiet-san-pham/'.$pro_encrypted)); ?>">
									<div class="col-sm-4">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="../public/upload/product/<?php echo e($rela->product_image); ?>" height="255px" alt="" />
												<h2><?php echo e(number_format($rela->product_price)); ?> VNĐ</h2>
												<p><?php echo e($rela->product_name); ?></p>
												<form action="<?php echo e(URL::to('/save-cart')); ?>" method="POST">
													<?php echo e(csrf_field()); ?>

													<input name="qty" type="hidden" value="1" />
													<input name="productid_hidden" type="hidden" value="<?php echo e($rela->product_id); ?>" />
													<button style="height:35px; width:150px;" type="submit" class="btn btn-fefault cart">
														<i class="fa fa-shopping-cart"></i>
														Add to cart
													</button>&nbsp; &nbsp; &nbsp;
												</form>
											</div>
										</div>
									</div>
									</a>	
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>   
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/product/show_detail.blade.php ENDPATH**/ ?>