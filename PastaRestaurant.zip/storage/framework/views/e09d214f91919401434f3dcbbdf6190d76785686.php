<?php $__env->startSection('content'); ?>   

<section id="cart_items">
		<div class="container clearfix">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a></li>
				  <li class="active">Đơn hàng của bạn</li>
				</ol>
			</div>
            <?php
				use Illuminate\Support\Facades\Session;
				$message = Session::get('message');
				if ($message) {
					echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">' . $message . '</span>';
					Session::put('message', null);
				}
			?>
		<div class="col-sm-10 clearfix">
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td>STT</td>
							<td class="description">Mã đơn hàng</td>
							<td class="price">Ngày đặt hàng</td>
							<td class="quantity">Tình trạng đơn hàng</td>
							<td class="total"></td>
							<td></td>
						</tr>
					</thead>
					<tbody>
                    <?php
                    $i = 0;
                    ?>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $i++;
                    ?>
                    <tr>
                        <td><i><?php echo e($i); ?></i></td>
                        <td><?php echo e($ord->order_code); ?></td>
                        <td><?php echo e($ord->created_at); ?></td>
                        <td>
                            <?php
                            if ($ord->order_status == 1) {
                                echo 'Đang chờ xác nhận';
                            } elseif ($ord->order_status == 2) {
                                echo 'Đã xác nhận';
                            } elseif ($ord->order_status == 3) {
                                echo 'Đã hoàn thành';
                            } elseif ($ord->order_status == 0) {
                                echo 'Đã hủy';
                            }
                            ?>
                        </td>
                        <td>
                        <?php if($ord->order_status == 1): ?>
                        <form role="form" action="<?php echo e(URL::to('/del-order/'.$ord->order_code)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="order_status" value="0"/>
                            <button type="submit" name="del-order" class="btn btn-danger">Hủy đơn</button>
                        </form>
                        <?php elseif($ord->order_status == 0): ?>
                            Đơn hàng đã hủy
                        <?php else: ?>
                            Đơn hàng không thể hủy
                        <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
		</div>
</section> <!--/#cart_items-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/show_order.blade.php ENDPATH**/ ?>