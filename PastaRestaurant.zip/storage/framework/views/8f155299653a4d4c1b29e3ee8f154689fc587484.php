<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
            Thông tin sản phẩm
            </div>  
            <div class="table-responsive">
                <?php
                 use Illuminate\Support\Facades\Session;
                    $message = Session::get('message');
                    if($message){
                        echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">'.$message.'</span>';
                        Session::put('message',null);
                    }
                ?>
            <table class="table table-striped b-t b-light">
                <thead>
                <tr>
                    <th>Tên Sản phẩm</th>
                    <th>Giá</th>
                    <th>Hình sản phẩm</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $all_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pro->product_name); ?></td>
                    <td><?php echo e($pro->product_price); ?></td>
                    <td><img src="public/upload/product/<?php echo e($pro->product_image); ?>" height="100" width="100"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <br>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Liệt kê nguyên vật liệu
    </div>
    </div>
    <div class="table-responsive">
      <?php
      $message = Session::get('message');
      if ($message) {
        echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">' . $message . '</span>';
        Session::put('message', null);
      }
      ?>
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>Tên nguyên vật liệu</th>
            <th>Số lượng tồn</th>
            <th>Đơn vị đo</th>
            <th>Trạng thái</th>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $all_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
            <td><?php echo e($deta->material_name); ?></td>
            <td><?php echo e($deta->material_details_qty); ?></td>
            <td>
              <?php
                if ($deta->material_details_unit == 0) {
                  echo 'Kg (Kilogram)';
                } elseif ($deta->material_details_unit == 1) {
                  echo 'g (gram)';
                } elseif ($deta->material_details_unit == 2) {
                  echo 'L (liter)';
                } elseif ($deta->material_details_unit == 3) {
                  echo 'ml (milliliter)';
                } elseif ($deta->material_details_unit == 4) {
                  echo 'Hộp';
                } elseif ($deta->material_details_unit == 5) {
                  echo 'chai';
                } elseif ($deta->material_details_unit == 6) {
                  echo 'trái';
                }
              ?>
            </td>
            <td>
              <a href="<?php echo e(URL::to('/edit-material_details/'.$deta->material_details_id)); ?>" class="active styling-edit" ui-toggle-class="">
                <i class="fa fa-pencil-square-o text-success text-active"></i></a>
              </br>
              <a onclick="return confirm('Bạn có chắc muốn xóa chi tiết sản phẩm này không?')" href="<?php echo e(URL::to('/delete-material_details/'.$deta->material_details_id)); ?>" class="active styling-edit" ui-toggle-class="">
                <i class="fa fa-times text-danger text"></i></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/admin/all_material_details.blade.php ENDPATH**/ ?>