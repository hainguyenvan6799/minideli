<div class="col-sm-3">
		<div class="left-sidebar" >
			<h2>Danh mục sản phẩm</h2>
			<div class="panel-group category-products" id="accordian"><!--category-productsr-->
				<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="<?php echo e(URL::to('/danh-muc-san-pham/'.$cate->category_id)); ?>">
						<?php echo e($cate->category_name); ?></a></h4>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div><!--/category-products-->
			
			<div class="shipping text-center"><!--shipping-->
				<img src="<?php echo e(URL::to('/public/frontend/images/shipping.jpg')); ?>" alt="" />
			</div><!--/shipping-->
		
		</div>
	</div><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/elements/category_list.blade.php ENDPATH**/ ?>