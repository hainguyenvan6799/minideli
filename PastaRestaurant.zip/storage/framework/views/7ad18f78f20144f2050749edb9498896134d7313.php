<?php $__env->startSection('admin_content'); ?>
<div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Cập nhật thương hiệu sản phẩm
                        </header>
                        <div class="panel-body">
                            <?php
                                use Illuminate\Support\Facades\Session;
                                $message = Session::get('message');
                                if($message){
                                    echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">'.$message.'</span>';
                                    Session::put('message',null);
                                }
                            ?>
                            <?php $__currentLoopData = $edit_material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="position-center">
                                <form role="form" action="<?php echo e(URL::to('/update-material/'.$edit_value->material_id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên nguyên vật liệu</label>
                                    <input type="text" value="<?php echo e($edit_value->material_name); ?>" name="material_name" class="form-control" id="exampleInputEmail1" 
                                    placeholder="Tên thương hiệu">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Số lượng tồn</label>
                                    <textarea style="resize: none" rows="5" class="form-control" name="material_qty" 
                                    id="exampleInputPassword1" ><?php echo e($edit_value->material_qty); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Đơn vị đo</label>
                                    <select name="material_unit" class="form-control input-sm m-bot15">
                                        <option value="<?php echo e($edit_value->material_unit); ?>">
                                        <?php
                                            if ($edit_value->material_unit == 0) {
                                                echo 'Kg (Kilogram)';
                                            } elseif($edit_value->material_unit == 1) {
                                                echo 'g (gram)';
                                            } elseif($edit_value->material_unit == 2) {
                                                echo 'L (liter)';
                                            } elseif($edit_value->material_unit == 3) {
                                                echo 'ml (milliliter)';
                                            } elseif($edit_value->material_unit == 4) {
                                                echo 'Hộp';
                                            } elseif($edit_value->material_unit == 5) {
                                                echo 'chai';
                                            } elseif($edit_value->material_unit == 6) {
                                                echo 'trái';
                                            }
                                        ?>
                                        </option>
                                        <option value="0">Kg (Kilogram)</option>
                                        <option value="1">g (gram)</option>
                                        <option value="2">L (liter)</option>
                                        <option value="3">ml (milliliter)</option>
                                        <option value="4">Hộp</option>
                                        <option value="5">chai</option>
                                        <option value="6">trái</option>
                                    </select>
                                </div>
                                <button type="submit" name="update_material" class="btn btn-info">Cập nhật nguyên vật liệu</button>
                            </form>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/admin/edit_material.blade.php ENDPATH**/ ?>