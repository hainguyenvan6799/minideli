<?php $__env->startSection('content'); ?>

<section id="cart_items">
	<div class="container clearfix">
		<div class="breadcrumbs">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a></li>
				<li class="active">Giỏ hàng của bạn</li>
			</ol>
		</div>
		<?php

		use Illuminate\Support\Facades\Session;

		$session_cart = Session::get('cart');
		$session_coupon = Session::get('coupon');
		$session_customer = Session::get('customer_id');
		$message = Session::get('message');
		if ($message) {
			echo ' <div class="alert alert-success col-sm-10 clearfix"> 
					<span class="text-alert" style="width: auto;font-size: 17px;">' . $message . '</span>
				   </div>';
			Session::put('message', null);
		}
		?>
		<div class="col-sm-10 clearfix">
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
				<form action="<?php echo e(URL::to('/update-cart')); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

					<thead>
						<tr class="cart_menu">
							<td class="image col-sm-2">Hình ảnh</td>
							<td class="description col-sm-2">Tên sản phẩm</td>
							<td class="price col-sm-2">Giá sản phẩm</td>
							<td class="quantity col-sm-2">Số lượng</td>
							<td class="total col-sm-2">Thành tiền tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php if($session_cart !== null): ?>
						<?php
						$total = 0;
						?>
						<?php $__currentLoopData = $session_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
						$subtotal = $cart['product_price'] * $cart['product_qty'];
						$total += $subtotal;
						?>
						<tr>
							<td class="cart_product col-sm-2">
								<a href=""><img src="<?php echo e(URL::to('/public/upload/product/'.$cart['product_image'])); ?>" width="70px" height="70px" alt=""></a>
							</td>
							<td class="cart_description col-sm-2">
								<h4><a style="font-size: 17px;" href=""><?php echo e($cart['product_name']); ?></a></h4>
							</td>
							<td class="cart_price col-sm-2">
								<p style="font-size: 17px;"><?php echo e(number_format($cart['product_price'],0,',','.')); ?> vnđ</p>
							</td>
							<td class="cart_quantity col-sm-2">
								<div class="cart_quantity_button">
									<input style="width: 150px;" class="cart_quantity_" type="number" min="1" name="cart_qty[<?php echo e($cart['session_id']); ?>]" value="<?php echo e($cart['product_qty']); ?>" autocomplete="off" size="2">
								</div>
							</td>
							<td class="cart_total col-sm-2">
								<p style="font-size: 17px;" class="cart_total_price"><?php echo e(number_format($subtotal,0,',','.')); ?>vnđ</p>
							</td>
							<td class="cart_delete" style="padding-top: 30px;">
								<a class="cart_quantity_delete" href="<?php echo e(URL::to('/del-product/'.$cart['session_id'])); ?>"><i class="fa fa-times"></i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><input type="submit" value="Cập nhật giỏ hàng" name="update_qty" class="btn btn-default check_out" /></td>
							<td><a class="btn btn-default check_out" href="<?php echo e(URL::to('/del-all-product')); ?>">Xóa tất cả sản phẩm</a></td>
							<?php if($session_coupon !== null): ?>
							<td><a class="btn btn-default check_out" href="<?php echo e(URL::to('/unset-coupon')); ?>">Xóa mã giảm giá</a></td>
							<?php endif; ?>

							<?php if($session_customer !== null): ?>
							<td><a class="btn btn-default check_out" href="<?php echo e(URL::to('/checkout')); ?>">Đặt hàng</a></td>
							<?php else: ?>
							<td><a class="btn btn-default check_out" href="<?php echo e(URL::to('/login-checkout')); ?>">Đặt hàng</a></td>
							<?php endif; ?>

							<td colspan="2">
								<li>Tổng tiền: <span><?php echo e(number_format($total,0,',','.')); ?> vnđ</span></li>
								<?php if($session_coupon !== null): ?>
							<li>
									<?php if($session_coupon['coupon_condition']==1): ?>
										Mã giảm : <?php echo e($session_coupon['coupon_number']); ?> %
										<p>
											<?php 
											$total_coupon = ($total*$session_coupon['coupon_number'])/100;
											echo '<p><li>Tổng giảm:'.number_format($total_coupon,0,',','.').' vnđ</li></p>';
											?>
										</p>
										<p><li>Tổng đã giảm :<?php echo e(number_format($total-$total_coupon,0,',','.')); ?> vnđ</li></p>
									<?php elseif($session_coupon['coupon_condition']==2): ?>
										Mã giảm : <?php echo e(number_format($session_coupon['coupon_number'],0,',','.')); ?> vnđ
										<p>
											<?php 
											$total_coupon = $total - $session_coupon['coupon_number'];
											?>
										</p>
										<p><li>Tổng đã giảm : <?php echo e(number_format($total_coupon,0,',','.')); ?> vnđ</li></p>
									<?php endif; ?>
							</li>
							<?php endif; ?> 
								<!-- <li>Thuế <span> 0 VNĐ</span></li>
								<li>Phí vận chuyển <span>Free</span></li>
								<li>Tiền sau giảm<span> VNĐ</span></li> -->
							</td>
						</tr>
					<?php else: ?>
						<tr><td colspan="5">
							<?php
								echo 'Không có sản phẩm trong giỏ hàng';
							?>
						</td></tr>
					<?php endif; ?>
					</tbody>
				</form>
				<?php if($session_cart !== null): ?>
				<tr>
					<td>
						<form action="<?php echo e(URL::to('/check-coupon')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<input type="text" class="form=control" name="coupon" placeholder="Nhập mã giảm giá" >
							<input type="submit" class="btn btn-default check_coupon" name="check_coupon" value="Thêm mã giảm giá">
						</form>
					</td>
				</tr>
				<?php endif; ?>
				</table>
				
			</div>
		</div>
	</div>
</section>
<!--/#cart_items-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/cart/cart_ajax.blade.php ENDPATH**/ ?>