<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm chi tiết sản phẩm
            </header>
            <div class="panel-body">
                <?php

                use Illuminate\Support\Facades\Session;

                $message = Session::get('message');
                if ($message) {
                    echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">' . $message . '</span>';
                    Session::put('message', null);
                }
                ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/save-material-details')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Lỗi!</strong> Kiểm tra lại thông tin đã nhập!.
                            <br />
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên sản phẩm</label>
                            <select name="product_id" class="form-control input-sm m-bot15">
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pro->product_id); ?>"><?php echo e($pro->product_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tên nguyên vật liệu</label>
                            <select name="material_id" class="form-control input-sm m-bot15">
                                <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mate->material_id); ?>"><?php echo e($mate->material_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Số lượng cần</label>
                            <input type="text" name="material_qty" class="form-control" id="exampleInputEmail1" placeholder="Tên danh mục">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Đơn vị đo</label>
                            <select name="material_unit" class="form-control input-sm m-bot15">
                                <option value="0">Kg (Kilogram)</option>
                                <option value="1">g (gram)</option>
                                <option value="2">L (liter)</option>
                                <option value="3">ml (millilit)</option>
                                <option value="4">Hộp</option>
                                <option value="5">chai</option>
                            </select>
                        </div>
                        <button type="submit" name="add_material_details" class="btn btn-info">Thêm chi tiết sản phẩm </button>
                    </form>
                </div>

            </div>
            <div id="load_material_details"></div>
        </section>
        
    </div>
    
    

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/admin/add_material_details.blade.php ENDPATH**/ ?>