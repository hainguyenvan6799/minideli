<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('pages.elements.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<div class="container">
	<?php echo $__env->make('pages.elements.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('pages.elements.category_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<div class="col-sm-9 padding-right">
	<?php echo $__env->make('pages.elements.product_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<center>
		<?php echo $all_product->render(); ?>

	</center>
	</div>
</div>
<?php echo $__env->make('pages.elements.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.elements.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/product.blade.php ENDPATH**/ ?>