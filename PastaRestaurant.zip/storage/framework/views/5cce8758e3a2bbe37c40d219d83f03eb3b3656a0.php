<?php $__env->startSection('content'); ?>   

    <section id="cart_items">
		<div class="container col-sm-12 clearfix">
			
			<h4> Cám ơn bạn đã đặt hàng </h4>
            <br/>
            
	</section> <!--/#cart_items-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/checkout/handcash.blade.php ENDPATH**/ ?>