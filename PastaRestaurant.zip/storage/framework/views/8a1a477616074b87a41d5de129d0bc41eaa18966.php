<?php $__env->startSection('admin_content'); ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
            Thông tin khách hàng
            </div>  
            <div class="table-responsive">
                <?php
                    use Illuminate\Support\Facades\Session;
                    use App\Product;
                    use App\Order;
                    use Illuminate\Support\Facades\Crypt;
                    $message = Session::get('message');
                    if($message){
                        echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">'.$message.'</span>';
                        Session::put('message',null);
                    }
                ?>
            <table class="table table-striped b-t b-light">
                <thead>
                <tr>
                    <th>Tên khách hàng</th>
                    <th>Số điện thoại</th>
                    <th>Email</th>
                    <th>Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($customer->customer_name); ?></td>
                    <td><?php echo e($customer->customer_phone); ?></td>
                    <td><?php echo e($customer->customer_email); ?></td>
                    <td>
                        <?php if($customer->customer_status == 0): ?>
                            <?php
                                echo 'Bình thường';
                            ?>
                        <?php elseif($customer->customer_status == 1): ?>
                            <?php
                                echo 'Đã khóa';
                            ?>
                        <?php endif; ?>
                    </td>
                </tr>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <br>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
            Thông tin vận chuyển
            </div>
            
            <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                <tr>
                    <th>Tên người nhận</th>
                    <th>Địa chỉ</th>
                    <th>Số điện thoại</th>
                    <th>Ghi chú</th>
                    <th>Hình thức thanh toán</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($shipping->shipping_name); ?></td>
                    <td><?php echo e($shipping->shipping_address); ?></td>
                    <td><?php echo e($shipping->shipping_phone); ?></td>
                    <td><?php echo e($shipping->shipping_note); ?></td>
                    <td>
                        <?php
                            if ($shipping->shipping_method == 0) {
                                echo 'Chuyển khoản';
                            } elseif ($shipping->shipping_method == 1) {
                                echo 'Trả khi nhận hàng';
                            }
                        ?>
                    </td>
                </tr>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <br><br>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
            Liệt kê chi tiết đơn hàng
            </div>
            
            <div class="table-responsive">
                <?php
                    $message = Session::get('message');
                    if($message){
                        echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">'.$message.'</span>';
                        Session::put('message',null);
                    }
                ?>
            <table class="table table-striped b-t b-light">
                <thead>
                <tr>
                    <th>STT</th>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng tồn</th>
                    <th>Số lượng</th>
                    <th>Giá</th>
                    <th>Mã giảm giá</th>
                    <th>Tổng tiền</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $i = 0;
                    $total = 0;
                ?>
                <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;
                    $subtotal = $detail->product_sales_quantity * $detail->product_price;
                    $total += $subtotal;
                    $ord = Order::where('order_code',$detail->order_code)->first();
                    $pro = Product::where('product_id',$detail->product_id)->first();
                    $pro_encryted = Crypt::encryptString((string)$detail->product_id);
                ?>
                <tr>
                    <td><i><?php echo e($i); ?></i></td>
                    <td><a href="<?php echo e(URL::to('/material-details/'.$pro_encryted)); ?>"><?php echo e($detail->product_name); ?></a></td>
                    <td><?php echo e($pro->product_quantity); ?></td>
                    <td><?php echo e($detail->product_sales_quantity); ?></td>
                    <td><?php echo e(number_format($detail->product_price,0,',','.')); ?> vnđ</td>
                    <td><?php echo e($detail->product_coupon); ?></td>
                    <td><?php echo e(number_format($subtotal,0,',','.')); ?> vnđ</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="2">
                        <?php
                            $total_after_coupon = 0;
                            $total_coupon = 0;
                        ?>
                        <?php if($coupon_condition == 1): ?>
                            <?php
                                $total_coupon = ($total/100)*$coupon_number;
                                $total_after_coupon = $total - ($total*$coupon_number)/100;
                                $final = $total_after_coupon + $detail->product_feeship;
                            ?>
                        <?php else: ?>
                            <?php
                                $total_coupon = $coupon_number;
                                $total_after_coupon = $total - $coupon_number;
                                $final = $total_after_coupon + $detail->product_feeship;
                            ?>
                        <?php endif; ?>
                        Tồng hóa đơn : <?php echo e(number_format($total,0,',','.')); ?> vnđ
                        <?php 
                            echo '</br>';
                        ?>
                        Phí ship : <?php echo e(number_format($detail->product_feeship,0,',','.')); ?> vnđ
                        <?php 
                            echo '</br>';
                        ?>
                        Giảm giá : <?php echo e(number_format($total_coupon,0,',','.')); ?> vnđ
                        <?php 
                            echo '</br>';
                        ?>
                        <strong> Tổng thanh toán : <?php echo e(number_format($final,0,',','.')); ?> vnđ </strong>
                    </td>
                    <td colspan="3">
                        <strong>Trạng thái đơn hàng:</strong>
                        <form role="form" action="<?php echo e(URL::to('/update-status/'.$ord->order_code)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php if(($ord->order_status == 1) || ($ord->order_status == 2)): ?>
                        <select name="order_status" class="form-control input-sm m-bot15 order_details">
                            <option value="<?php echo e($ord->order_status); ?>">
                            <?php
                            if ($ord->order_status == 1) {
                                echo 'Đang chờ xác nhận';
                            } elseif ($ord->order_status == 2) {
                                echo 'Đã xác nhận';
                            } elseif ($ord->order_status == 3) {
                                echo 'Đã hoàn thành';
                            } elseif ($ord->order_status == 0) {
                                echo 'Đã hủy';
                            }
                            ?>
                            </option>
                            <option value="1">Đang chờ xác nhận</option>
                            <option value="2">Đã xác nhận</option>
                            <option value="3">Đã hoàn thành</option>
                            <option value="0">Đã hủy</option>
                        </select>
                        <button type="submit" name="update_material" class="btn btn-info">Cập nhật trạng thái</button>
                        </form>
                        <?php else: ?>
                        <?php
                            if ($ord->order_status == 1) {
                                echo 'Đang chờ xác nhận';
                            } elseif ($ord->order_status == 2) {
                                echo 'Đã xác nhận';
                            } elseif ($ord->order_status == 3) {
                                echo 'Đã hoàn thành';
                            } elseif ($ord->order_status == 0) {
                                echo 'Đã hủy';
                            }
                            ?>
                    </td>
                        <?php endif; ?>
                    <td colspan="2">
                        </br>
                        </br>
                        <?php if($customer->customer_status == 0): ?>
                        <a target="_blank" href="<?php echo e(url('/print-order/'.$detail->order_code)); ?>" class="btn btn-success">In đơn hàng</a>
                        <?php else: ?>
                            Khách hàng đang trong trạng thái khóa, không thể in đơn hàng
                        <?php endif; ?>
                    </td>
                </tr>
                </tbody>
            </table>
            
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/admin/view_order.blade.php ENDPATH**/ ?>