<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Liệt kê danh mục sản phẩm
    </div>

  </div>
  <div class="table-responsive">
    <?php

    use Illuminate\Support\Facades\Session;
    use Illuminate\Support\Facades\Crypt;

    $message = Session::get('message');
    if ($message) {
      echo '<span class="text-alert" style="width: auto;font-size: 17px;color: #D81B60;">' . $message . '</span>';
      Session::put('message', null);
    }
    ?>
    <table class="table table-striped b-t b-light">
      <thead>
        <tr>
          <th>Tên danh mục</th>
          <th>Hiển thị</th>
          <th>Ngày thêm</th>
          <th style="width:30px;"></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $all_category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $cate_encrypted = Crypt::encryptString((string)$cate_pro->category_id);
        ?>
        <tr>
          <td><?php echo e($cate_pro->category_name); ?></td>
          <td><span class="text-ellipsis">
              <?php
              if ($cate_pro->category_status == 0) {
              ?>
                <a href="<?php echo e(URL::to('/active-category-product',$cate_encrypted)); ?>"><span class="fa-thumb-styling fa fa-thumbs-up"></span></a>
              <?php
              } else {
              ?>
                <a href="<?php echo e(URL::to('/unactive-category-product',$cate_encrypted)); ?>"><span class="fa-thumb-styling fa fa-thumbs-down"></span></a>
              <?php
              }
              ?>
            </span></td>
          <td>
            <a href="<?php echo e(URL::to('/edit-category-product/'.$cate_encrypted)); ?>" class="active styling-edit" ui-toggle-class="">
              <i class="fa fa-pencil-square-o text-success text-active"></i></a>
            </br>
            <a onclick="return confirm('Bạn có chắc muốn xóa danh mục này không?')" href="<?php echo e(URL::to('/delete-category-product/'.$cate_encrypted)); ?>" class="active styling-edit" ui-toggle-class="">
              <i class="fa fa-times text-danger text"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <!-- IMPORT DATA -->
              <form action="<?php echo e(url('import-csv')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" accept=".xlsx"><br>
                <input type="submit" value="Nhập danh mục sản phẩm" name="import_csv" class="btn btn-warning">
              </form>
            </td>
            <td> <!-- EXPORT DATA -->
              <form action="<?php echo e(url('export-csv')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="submit" value="Xuất danh mục sản phẩm" name="export_csv" class="btn btn-success">
              </form>
            </td>
        </tr>
      </tbody>
    </table>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/admin/all_category_product.blade.php ENDPATH**/ ?>