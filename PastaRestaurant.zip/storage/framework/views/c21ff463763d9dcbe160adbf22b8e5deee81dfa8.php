<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Gửi mail google</title>
</head>
<body>
    <h2>Mail được gửi từ : <?php echo e($name); ?></h2>
    <h3>Với nội đung : <?php echo e($body); ?></h3>
</body>
</html><?php /**PATH D:\xampp\htdocs\PastaRestaurant\resources\views/pages/send_mail.blade.php ENDPATH**/ ?>