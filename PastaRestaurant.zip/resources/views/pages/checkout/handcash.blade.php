@extends('layout')
@section('content')   

    <section id="cart_items">
		<div class="container col-sm-12 clearfix">
			
			<h4> Cám ơn bạn đã đặt hàng </h4>
            <br/>
            
	</section> <!--/#cart_items-->
@endsection